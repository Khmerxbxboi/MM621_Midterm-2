// --- Data & Global Variables ---
let imgBackground;
let maxScore = 6.3; 
let infoPanel; 
let currentSortKey = 'score'; 

// Data: Full data set with 6 factors (from 2019.csv for SEA region)
let SEA_DATA = [
    { country: "Myanmar", score: 4.360, gdp: 0.710, support: 1.181, health: 0.555, freedom: 0.525, generosity: 0.566, corruption: 0.172 },
    { country: "Cambodia", score: 4.476, gdp: 0.603, support: 1.184, health: 0.633, freedom: 0.605, generosity: 0.287, corruption: 0.046 },
    { country: "Vietnam", score: 5.175, gdp: 0.748, support: 1.419, health: 0.871, freedom: 0.505, generosity: 0.165, corruption: 0.076 },
    { country: "Indonesia", score: 5.196, gdp: 0.940, support: 1.159, health: 0.637, freedom: 0.513, generosity: 0.297, corruption: 0.038 },
    { country: "Laos", score: 5.203, gdp: 0.528, support: 1.042, health: 0.449, freedom: 0.449, generosity: 0.228, corruption: 0.183 },
    { country: "Philippines", score: 5.631, gdp: 0.812, support: 1.209, health: 0.614, freedom: 0.662, generosity: 0.300, corruption: 0.120 },
    { country: "Thailand", score: 6.008, gdp: 1.050, support: 1.408, health: 0.760, freedom: 0.520, generosity: 0.357, corruption: 0.055 },
    { country: "Malaysia", score: 6.088, gdp: 1.156, support: 1.258, health: 0.766, freedom: 0.407, generosity: 0.291, corruption: 0.041 },
    { country: "Singapore", score: 6.262, gdp: 1.574, support: 1.306, health: 1.141, freedom: 0.549, generosity: 0.271, corruption: 0.464 }
];

// Bar properties
const CANVAS_W = 800;
const CANVAS_H = 550;
const barW = 60;
const barSpacing = 85;
let startX;
const baselineY = CANVAS_H - 50; 
const BASE_COLOR = 40; 
const HIGHLIGHT_COLOR = [255, 153, 0]; // RGB for Vibrant Gold/Orange

// --- P5.js Required Functions ---

function preload() {
    imgBackground = loadImage('image_b701a4.jpg'); 
}

function setup() {
    const canvas = createCanvas(CANVAS_W, CANVAS_H); 
    canvas.parent('visualization-container'); 
    
    infoPanel = document.getElementById('data-display');
    
    const totalWidth = SEA_DATA.length * barSpacing;
    startX = (CANVAS_W - totalWidth) / 2 + barSpacing / 2;
    
    textSize(14);
    sortData('score', document.getElementById('sort-score')); 
    
    noLoop(); 
}

function draw() {
    // 1. Draw the Background Image
    image(imgBackground, 0, 0, CANVAS_W, CANVAS_H); 
    
    // 2. Draw a LOW-OPACITY dark overlay (120/255) to make the image POP
    fill(0, 0, 0, 120); 
    rect(0, 0, CANVAS_W, CANVAS_H);

    let isHoveringAny = false;
    stroke(100);
    line(0, baselineY, CANVAS_W, baselineY);

    for (let i = 0; i < SEA_DATA.length; i++) {
        const data = SEA_DATA[i];
        
        const barHeight = map(data.score, 4.3, 6.3, 50, 450); 
        const barX = startX + i * barSpacing - barW / 2;
        const barY = baselineY - barHeight; 
        
        const isHovering = mouseX > barX && mouseX < barX + barW && mouseY > barY && mouseY < baselineY;

        push();
        
        if (isHovering) {
            isHoveringAny = true;
            
            // HOVER STYLE: Vibrant Gold/Orange Highlight
            fill(HIGHLIGHT_COLOR[0], HIGHLIGHT_COLOR[1], HIGHLIGHT_COLOR[2]); 
            noStroke();
            rect(barX, barY, barW, barHeight);
            
            updateInfoPanel(data);
            
        } else {
            // NORMAL STYLE: Dark, Low-Contrast Bar
            fill(BASE_COLOR);
            stroke(60); 
            strokeWeight(1);
            rect(barX, barY, barW, barHeight);
        }
        pop();
        
        // --- 5. Draw Labels ---
        
        // Use the vibrant color for the label when hovering, otherwise use white/light gray
        if (isHovering) {
            fill(HIGHLIGHT_COLOR[0], HIGHLIGHT_COLOR[1], HIGHLIGHT_COLOR[2]); 
        } else {
            fill(255); 
        }

        textAlign(CENTER, BOTTOM);
        
        // Country Name on Top of the bar
        text(data.country, barX + barW / 2, barY - 10);
    }
    
    if (!isHoveringAny) {
        resetInfoPanel();
    }
}

// Function called by the HTML buttons (Interaction Design)
function sortData(key, buttonElement) {
    if (key === 'alpha') {
        SEA_DATA.sort((a, b) => a.country.localeCompare(b.country));
    } else if (key === 'score' || key === 'gdp') {
        SEA_DATA.sort((a, b) => a[key] - b[key]);
    }
    currentSortKey = key;
    
    document.querySelectorAll('.sort-button').forEach(btn => btn.classList.remove('active'));
    buttonElement.classList.add('active');
    
    redraw(); 
}

function mouseMoved() {
    if (mouseX >= 0 && mouseX <= CANVAS_W && mouseY >= 0 && mouseY <= CANVAS_H) {
        redraw(); 
    }
}

function updateInfoPanel(data) {
    // Note: The HTML color is set by the CSS variable --highlight-color
    infoPanel.innerHTML = `
        <p><span class="label">COUNTRY:</span> ${data.country}</p>
        <p><span class="label">SCORE:</span> <span style="color: var(--highlight-color); font-weight: 700;">${nf(data.score, 1, 3)}</span></p>
        <hr style="border-color: #555; margin: 15px 0;">
        <p style="font-size: 0.9em;"><span class="label">SORT KEY:</span> ${currentSortKey.toUpperCase()}</p>
        <p style="font-size: 0.8em;">*GDP per capita: ${nf(data.gdp, 1, 3)}</p>
        <p style="font-size: 0.8em;">Social support: ${nf(data.support, 1, 3)}</p>
        <p style="font-size: 0.8em;">Healthy life: ${nf(data.health, 1, 3)}</p>
        <p style="font-size: 0.8em;">Freedom: ${nf(data.freedom, 1, 3)}</p>
        <p style="font-size: 0.8em;">Generosity: ${nf(data.generosity, 1, 3)}</p>
        <p style="font-size: 0.8em;">Corruption: ${nf(data.corruption, 1, 3)}</p>
    `;
}

function resetInfoPanel() {
    infoPanel.innerHTML = `
        <p>Awaiting Country Selection...</p>
        <p style="font-size: 0.9em; opacity: 0.6; margin-top: 50px;">Use the sort buttons or hover over a pillar to load the full factor breakdown into the data stream.</p>
    `;
}